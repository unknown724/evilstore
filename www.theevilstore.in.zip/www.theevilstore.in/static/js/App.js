import "./App.css";
import "bootstrap/dist/css/bootstrap.min.css";
import {
    BrowserRouter,
    Route,
    Routes
} from "react-router-dom";
import {
    useEffect,
    useState
} from "react";
import Home from "./pages/Home";
import Register from "./pages/Register";
import Login from "./pages/Login";
import ForgotPass from "./pages/ForgotPass";
import Contact from "./pages/Contact";
import Dashboard from "./user/Dashboard";
import ProtectedRoute from "./components/ProtectedRoute";
import PublicRoute from "./components/PublicRoute";
import AdminDashboard from "./admin/AdminDashboard";
import AdminUsers from "./admin/AdminUsers";
import EditUser from "./admin/EditUser";
import AdminPayments from "./admin/AdminPayments";
import Terms from "./pages/Terms";
import PrivacyPolicy from "./pages/PrivacyPolicy";
import RefundPolicy from "./pages/RefundPolicy";
import AdminProduct from "./admin/AdminProduct";
import AdminAddProduct from "./admin/AdminAddProduct";
import AdminEditProduct from "./admin/AdminEditProduct";
import AdminOrder from "./admin/AdminOrder";
import ProductInfo from "./pages/ProductInfo";
import Orders from "./user/Orders";
import Account from "./user/Account";
import ViewOrder from "./user/ViewOrder";
import AdminViewOrder from "./admin/AdminViewOrder";
import AdminQueries from "./admin/AdminQueries";
import AdminGallery from "./admin/AdminGallery.js";
import Wallet from "./user/Wallet";
import Query from "./user/Query.js";
import GamePage from "./pages/GamePage.js";

function App() {
    return ( <
        BrowserRouter >
        <
        Routes > { /* pages */ } <
        Route path = "/"
        element = { < Home / >
        }
        /> <
        Route path = "/register"
        element = { <
            PublicRoute >
            <
            Register / >
            <
            /PublicRoute>
        }
        /> <
        Route path = "/login"
        element = { <
            PublicRoute >
            <
            Login / >
            <
            /PublicRoute>
        }
        /> <
        Route path = "/forgot-password"
        element = { < ForgotPass / >
        }
        /> <
        Route path = "/games"
        element = { < GamePage / >
        }
        /> <
        Route path = "/support"
        element = { < Contact / >
        }
        /> <
        Route path = "/product/:name?"
        element = { < ProductInfo / >
        }
        /> <
        Route path = "/orders"
        element = { <
            ProtectedRoute >
            <
            Orders / >
            <
            /ProtectedRoute>
        }
        /> <
        Route path = "/wallet"
        element = { <
            ProtectedRoute >
            <
            Wallet / >
            <
            /ProtectedRoute>
        }
        /> <
        Route path = "/query"
        element = { <
            ProtectedRoute >
            <
            Query / >
            <
            /ProtectedRoute>
        }
        />

        <
        Route path = "/my-account"
        element = { <
            ProtectedRoute >
            <
            Account / >
            <
            /ProtectedRoute>
        }
        /> <
        Route path = "/view-order/:orderId?"
        element = { <
            ProtectedRoute >
            <
            ViewOrder / >
            <
            /ProtectedRoute>
        }
        /> <
        Route path = "/terms"
        element = { < Terms / >
        }
        /> <
        Route path = "/privacy-policy"
        element = { < PrivacyPolicy / >
        }
        /> <
        Route path = "/refund-policy"
        element = { < RefundPolicy / >
        }
        /> { /* ======================== USER PAGES =============================== */ } { /* ========== EMAIL VERIFY */ } <
        Route path = "/user-dashboard"
        element = { <
            ProtectedRoute >
            <
            Dashboard / >
            <
            /ProtectedRoute>
        }
        /> { /* ======================== USER PAGES =============================== */ } { /* ======================== ADMIN PAGES =============================== */ }

        <
        Route path = "/admin-dashboard"
        element = { <
            ProtectedRoute >
            <
            AdminDashboard / >
            <
            /ProtectedRoute>
        }
        /> <
        Route path = "/admin-orders"
        element = { <
            ProtectedRoute >
            <
            AdminOrder / >
            <
            /ProtectedRoute>
        }
        /> <
        Route path = "/admin-view-order/:orderId?"
        element = { <
            ProtectedRoute >
            <
            AdminViewOrder / >
            <
            /ProtectedRoute>
        }
        /> <
        Route path = "/admin-products"
        element = { <
            ProtectedRoute >
            <
            AdminProduct / >
            <
            /ProtectedRoute>
        }
        /> <
        Route path = "/admin-add-product"
        element = { <
            ProtectedRoute >
            <
            AdminAddProduct / >
            <
            /ProtectedRoute>
        }
        /> <
        Route path = "/admin-edit-product/:id?"
        element = { <
            ProtectedRoute >
            <
            AdminEditProduct / >
            <
            /ProtectedRoute>
        }
        />

        <
        Route path = "/admin-users"
        element = { <
            ProtectedRoute >
            <
            AdminUsers / >
            <
            /ProtectedRoute>
        }
        /> <
        Route path = "/admin-edit-user/:id?"
        element = { <
            ProtectedRoute >
            <
            EditUser / >
            <
            /ProtectedRoute>
        }
        /> <
        Route path = "/admin-payments"
        element = { <
            ProtectedRoute >
            <
            AdminPayments / >
            <
            /ProtectedRoute>
        }
        /> <
        Route path = "/admin-queries"
        element = { <
            ProtectedRoute >
            <
            AdminQueries / >
            <
            /ProtectedRoute>
        }
        /> <
        Route path = "/admin-gallery"
        element = { <
            ProtectedRoute >
            <
            AdminGallery / >
            <
            /ProtectedRoute>
        }
        /> <
        /Routes> <
        /BrowserRouter>
    );
}

export default App;