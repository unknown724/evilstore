import React, {
    useEffect,
    useState
} from "react";
import {
    useNavigate
} from "react-router-dom";
import axios from "axios";
import "./Products.css";

const Games = ({
    title
}) => {
    const navigate = useNavigate();
    const [error, setError] = useState(null);
    const [products, setProducts] = useState(null);
    const [loading, setLoading] = useState(false);

    const getAllProducts = async () => {
        try {
            setLoading(true);
            const res = await axios.get("/api/product/get-all-products");
            if (res.data.success) {
                setProducts(res.data.data);
                setTimeout(() => {
                    setLoading(false);
                }, 1000);
            } else {
                setLoading(false);
            }
        } catch (error) {
            setLoading(false);
            console.log(error);
        }
    };

    useEffect(() => {
        getAllProducts();
    }, []);

    const renderCategory = (category) => {
        const filteredProducts = products ? .filter(
            (item) => item.category === category
        );
        if (filteredProducts && filteredProducts.length > 0) {
            return ( <
                div className = "popular-games" >
                <
                div className = "titlee" >
                <
                h5 > {
                    category
                } < /h5> <
                span onClick = {
                    () => navigate("/games")
                } > View More < /span> <
                /div> <
                div className = "games-list" > {
                    filteredProducts.map((item, index) => ( <
                        div key = {
                            index
                        }
                        className = "game"
                        onClick = {
                            () => navigate(`/product/${item?.name}`)
                        } >
                        <
                        img src = {
                            `https://theevilstore.in/${item?.image}`
                        }
                        alt = "pro-img" /
                        >
                        <
                        h5 > {
                            item ? .name
                        } < /h5> {
                            item ? .hotTags && ( <
                                div className = "hottag" >
                                <
                                span > {
                                    item ? .hotTags
                                } < /span> <
                                /div>
                            )
                        } <
                        /div>
                    ))
                } <
                /div> <
                /div>
            );
        }
        return null;
    };

    return ( <
        div className = "explore-products-container" > {
            renderCategory("Popular")
        } {
            renderCategory("Fast Process")
        } {
            renderCategory("Slow Process")
        } {
            renderCategory("Games")
        } {
            renderCategory("Social Media")
        } {
            renderCategory("OTT")
        } {
            renderCategory("BGMI")
        } {
            renderCategory("PUBG")
        } {
            renderCategory("Via Login")
        } {
            renderCategory("Premium")
        } {
            renderCategory("Voucher")
        } {
            renderCategory("Others")
        } <
        /div>
    );
};

export default Games;