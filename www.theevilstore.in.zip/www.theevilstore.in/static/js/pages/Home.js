import React, {
    useEffect,
    useState
} from "react";
import Layout from "../components/Layout/Layout";
import HeroSection from "../components/Home/HeroSection";
import HowItWorks from "../components/Home/HowItWorks";
import Products from "../components/Products";
import axios from "axios";
import {
    useNavigate,
    useParams
} from "react-router-dom";
import "./Home.css";

const Home = () => {
    const getUserData = async () => {
        axios
            .post(
                "/api/user/getUserData", {}, {
                    headers: {
                        Authorization: "Bearer " + localStorage.getItem("token"),
                    },
                }
            )
            .then((res) => {
                if (res.data.success) {} else {
                    localStorage.removeItem("token");
                }
            })
            .catch((error) => {
                console.log(error);
            });
    };

    useEffect(() => {
        getUserData();
    }, []);

    useEffect(() => {
        const handleBeforeUnload = (event) => {
            event.preventDefault();
            event.returnValue = "Are you sure you want quit?";
            localStorage.setItem("giveaway", "true");
        };
        window.addEventListener("beforeunload", handleBeforeUnload);
        return () => {
            window.removeEventListener("beforeunload", handleBeforeUnload);
        };
    }, []);

    return ( <
        Layout >
        <
        div className = "main-home-container" >
        <
        HeroSection / >
        <
        Products title = {
            "Trending Games"
        }
        /> <
        HowItWorks / >
        <
        /div> <
        /Layout>
    );
};

export default Home;