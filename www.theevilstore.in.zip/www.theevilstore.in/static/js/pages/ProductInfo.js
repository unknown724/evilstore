import React, {
    useEffect,
    useState
} from "react";
import {
    message
} from "antd";
import {
    useDispatch,
    useSelector
} from "react-redux";
import {
    setUser
} from "../redux/features/userSlice.js";
import {
    useNavigate,
    useParams
} from "react-router-dom";
import Layout from "../components/Layout/Layout";
import axios from "axios";
import getUserData from "../utils/userDataService.js";
import WalletIcon from "@mui/icons-material/Wallet";
import "./ProductInfo.css";
import IMAGES from "../img/image.js";

const ProductInfo = () => {
    const params = useParams();
    const navigate = useNavigate();
    const dispatch = useDispatch();

    const {
        user
    } = useSelector((state) => state.user);
    const [loading, setLoading] = useState(false);
    const [playerCheck, setPlayerCheck] = useState(null);
    const [product, setProduct] = useState(0);
    const [mode, setMode] = useState("WALLET");
    const [paymentOptions, setPaymentOptions] = useState("");
    //!NEW STATE
    const [amount, setAmount] = useState(null);
    const [selectedPrice, setSelectedPrice] = useState(null);
    const [productId, setProductId] = useState("");
    //! API BASED
    const [orderId, setOrderId] = useState(false);
    const [userId, setUserId] = useState("");
    const [zoneId, setZoneId] = useState("");
    const [balance, setBalance] = useState("");
    const [couponApplied, setCouponApplied] = useState(null);
    const [finalAmount, setFinalAmount] = useState("");

    useEffect(() => {
        getUserData(dispatch, setUser, setBalance);
    }, []);

    function setPriceAndId(amount) {
        if (user ? .reseller === "yes") {
            const price = product ? .cost ? .find(
                (item) => item.amount === amount
            ) ? .resPrice;
            setSelectedPrice(price);
            setFinalAmount(price);
            if (couponApplied) {
                setCouponApplied(false);
            }
            const id = product ? .cost ? .find((item) => item.amount === amount) ? .id;
            setProductId(id);
        } else {
            const price = product ? .cost ? .find(
                (item) => item.amount === amount
            ) ? .price;
            setSelectedPrice(price);
            setFinalAmount(price);
            if (couponApplied) {
                setCouponApplied(false);
            }
            const id = product ? .cost ? .find((item) => item.amount === amount) ? .id;
            setProductId(id);
        }
    }

    const getProduct = async () => {
        try {
            const res = await axios.post("/api/product/get-product-by-name", {
                name: params.name,
            });
            if (res.data.success) {
                setProduct(res.data.data);
                const defaultAmount = res.data.data ? .cost ? .[0] ? .amount;
                const defaultPrice =
                    user ? .reseller === "yes" ?
                    res.data.data ? .cost ? .[0] ? .resPrice :
                    res.data.data ? .cost ? .[0] ? .price;
                const defaultId = res.data.data ? .cost ? .[0] ? .id;
                setAmount(defaultAmount);
                setSelectedPrice(defaultPrice);
                setFinalAmount(defaultPrice);
                setProductId(defaultId);
            } else {
                message.error(res.data.message);
            }
        } catch (error) {
            console.log(error);
        }
    };

    useEffect(() => {
        getProduct();
    }, []);

    const generateOrderId = () => {
        const numbers = "01234567"; // 8 numbers
        const randomNumbers = Array.from({
                length: 7
            }, () =>
            numbers.charAt(Math.floor(Math.random() * numbers.length))
        );
        const now = new Date();
        const day = String(now.getDate()).padStart(2, "0");
        const month = String(now.getMonth() + 1).padStart(2, "0"); // getMonth() is 0-indexed
        const year = String(now.getFullYear()).slice(2); // last two digits of the year
        const seconds = String(now.getSeconds()).padStart(2, "0");
        const orderId = `${year}${month}${day}${seconds}${randomNumbers.join("")}`;
        setOrderId(orderId);
    };

    useEffect(() => {
        generateOrderId();
    }, []);

    async function handleCheckPlayer() {
        if (userId === "" || zoneId === "") {
            return message.error(
                `${userId === "" ? "Enter User ID" : "Enter (   Zone ID   )"}`
            );
        }
        try {
            // setLoading(true);
            const idPro = productId.split("&")[0];
            const object = {
                region: product ? .apiName === "smileOne" ? product ? .region : "brazil",
                userid: userId,
                zoneid: zoneId,
                productid: product ? .apiName === "smileOne" ? idPro : "13",
            };
            const res = await axios.post("/api/payment/get-role", object);
            if (res.data.success) {
                setPlayerCheck(res.data.username);
                setLoading(false);
            } else {
                message.error(res.data.message);
                setLoading(false);
            }
        } catch (error) {
            console.log(error);
            setLoading(false);
        }
    }

    function checkPlaceOrder(e) {
        if (product ? .fields === "2") {
            if (userId === "") {
                return message.error(`Enter ${product?.tagOne}`);
            }
            if (zoneId === "") {
                return message.error(`Enter ${product?.tagTwo}`);
            }
        } else if (product ? .fields === "1") {
            if (userId === "") {
                return message.error(`Enter ${product?.tagOne}`);
            }
        }
        if (!playerCheck && product ? .playerCheckBtn === "yes") {
            return message.error("Check Playername");
        }

        if (product ? .api === "yes") {
            if (product ? .apiName === "smileOne") {
                if (mode === "UPI") {
                    handleSmileOneUpiOrder(e);
                } else {
                    handleSmileOneWalletOrder(e);
                }
            }
        } else {
            if (mode === "UPI") {
                handleUpiOrder(e);
            } else {
                handleWalletOrder(e);
            }
        }
    }

    // smile
    const handleSmileOneUpiOrder = async (e) => {
        e.preventDefault();
        try {
            const paymentObject = {
                order_id: orderId,
                txn_amount: finalAmount,
                product_name: product ? .region,
                customer_name: user ? .fname,
                customer_email: user ? .email,
                customer_mobile: user ? .mobile,
                callback_url: `https://theevilstore.in/api/smile/status?orderId=${orderId}`,
                txn_note: userId +
                    "@" +
                    zoneId +
                    "@" +
                    productId +
                    "@" +
                    product ? .name +
                    "@" +
                    amount +
                    "@" +
                    selectedPrice,
            };

            const response = await axios.post("/api/smile/create", paymentObject, {
                headers: {
                    Authorization: "Bearer " + localStorage.getItem("token"),
                },
            });
            if (response.data.success && response.data.data.status) {
                window.location.href = response.data.data.results.payment_url;
                setLoading(false);
            } else {
                message.error(response.data.message);
                setLoading(false);
            }
        } catch (error) {
            console.log(error);
        }
    };
    const handleSmileOneWalletOrder = async (e) => {
        if (parseInt(balance) < parseInt(finalAmount)) {
            return message.error("Balance is less for this order");
        }
        e.preventDefault();
        const orderObject = {
            orderId: orderId,
            userid: userId,
            zoneid: zoneId,
            productid: productId,
            region: product.region,
            customer_email: user ? .email,
            customer_mobile: user ? .mobile,
            pname: product ? .name,
            amount: amount,
            price: finalAmount,
            ogPrice: selectedPrice,
        };

        setLoading(true);
        const res = await axios.post("/api/smile/wallet", orderObject, {
            headers: {
                Authorization: "Bearer " + localStorage.getItem("token"),
            },
        });
        if (res.data.success) {
            message.success(res.data.message);
            setLoading(false);
        } else {
            setLoading(false);
            message.error(res.data.message);
        }
    };

    // manual
    const handleUpiOrder = async (e) => {
        e.preventDefault();
        try {
            const paymentObject = {
                order_id: orderId,
                txn_amount: finalAmount,
                txn_note: userId + "@" + zoneId + "@" + amount,
                product_name: product ? .name,
                customer_name: user ? .fname,
                customer_mobile: user ? .mobile,
                customer_email: user ? .email,
                callback_url: `https://theevilstore.in/api/manual/status?orderId=${orderId}`,
            };

            const response = await axios.post("/api/manual/create", paymentObject, {
                headers: {
                    Authorization: "Bearer " + localStorage.getItem("token"),
                },
            });
            if (response.data.success && response.data.data.status) {
                window.location.href = response.data.data.results.payment_url;
                setLoading(false);
            } else {
                message.error(response.data.message);
                setLoading(false);
            }
        } catch (error) {
            console.log(error);
        }
    };
    const handleWalletOrder = async (e) => {
        if (parseInt(balance) < parseInt(selectedPrice)) {
            return message.error("Balance is less for this order");
        }
        e.preventDefault();
        try {
            const orderObject = {
                api: "no",
                orderId: orderId,
                userid: userId,
                zoneid: zoneId,
                customer_email: user && user ? .email,
                customer_mobile: user && user ? .mobile,
                pname: product ? .name,
                amount: amount,
                price: finalAmount,
            };

            setLoading(true);
            const res = await axios.post("/api/manual/wallet", orderObject, {
                headers: {
                    Authorization: "Bearer " + localStorage.getItem("token"),
                },
            });
            if (res.data.success) {
                setLoading(false);
                message.success(res.data.message);
                navigate("/user-dashboard");
            } else {
                message.error(res.data.message);
                setLoading(false);
                localStorage.setItem("orderProcess", "no");
            }
        } catch (error) {
            console.log(error);
            setLoading(false);
            localStorage.setItem("orderProcess", "no");
        }
    };

    return ( <
        Layout > {
            loading ? ( <
                div className = "loading-container" >
                <
                div class = "spinner" >
                <
                div > < /div> <
                div > < /div> <
                div > < /div> <
                div > < /div> <
                div > < /div> <
                div > < /div> <
                div > < /div> <
                div > < /div> <
                div > < /div> <
                div > < /div> <
                /div> <
                /div>
            ) : ( <
                div className = "product-info-container" >
                <
                div className = "pic" >
                <
                div className = "product-info-img bg-fields" >
                <
                div className = "game-name" >
                <
                img src = {
                    `https://theevilstore.in/${product?.image}`
                }
                alt = "" / >
                <
                div > < /div> <
                /div> <
                hr className = "text-white" / >
                <
                p className = "m-0" >
                <
                h4 > {
                    product ? .name
                } < /h4> <
                small > Instruction: < /small> <
                /p> <
                p > {
                    product ? .desc
                } < /p> <
                /div> <
                /div>

                <
                div className = "product-info-content mb-2" > { /* ====================== FIELDS ===============  */ } { /* ====================== FIELDS ===============  */ } <
                div className = "bg-fields" >
                <
                h5 > Enter IDs < /h5> {
                    product ? .fields === "1" ? ( <
                        div className = "d-flex align-items-center" >
                        <
                        input className = "player-tag"
                        type = "text"
                        name = "userId"
                        placeholder = {
                            `${product?.tagOne}`
                        }
                        onChange = {
                            (e) => setUserId(e.target.value)
                        }
                        value = {
                            userId
                        }
                        /> <
                        /div>
                    ) : product ? .fields === "2" ? ( <
                        >
                        <
                        div className = "d-flex align-items-center" >
                        <
                        input className = "player-tag"
                        type = "text"
                        name = "userId"
                        placeholder = {
                            `${product?.tagOne}`
                        }
                        onChange = {
                            (e) => setUserId(e.target.value)
                        }
                        value = {
                            userId
                        }
                        /> <
                        /div> <
                        input className = "player-tag"
                        type = "text"
                        name = "zoneid"
                        placeholder = {
                            `${product?.tagTwo}`
                        }
                        onChange = {
                            (e) => setZoneId(e.target.value)
                        }
                        value = {
                            zoneId
                        }
                        /> {
                            loading && ( <
                                >
                                <
                                div class = "spinner-border spinner-border-sm me-2 mt-2"
                                role = "status" >
                                <
                                span class = "visually-hidden" > < /span> <
                                /div>
                                Checking Username <
                                />
                            )
                        } <
                        div >
                        <
                        span className = "text-success" > {
                            playerCheck && "Username: " + playerCheck
                        } <
                        /span> <
                        /div> <
                        />
                    ) : (
                        product ? .fields === "3" && ( <
                            >
                            <
                            div className = "d-flex align-items-center" >
                            <
                            input className = "player-tag"
                            type = "text"
                            name = "userId"
                            placeholder = {
                                `${product?.tagOne}`
                            }
                            onChange = {
                                (e) => setUserId(e.target.value)
                            }
                            value = {
                                userId
                            }
                            /> <
                            /div> <
                            select name = "zoneId"
                            className = "form-select player-tag text-white"
                            onChange = {
                                (e) => setZoneId(e.target.value)
                            } >
                            <
                            option value = "" > Select Server < /option> {
                                product ? .tagTwo ? .split("+") ? .map((item, index) => {
                                    return <option value = {
                                        item
                                    } > {
                                        item
                                    } < /option>;
                                })
                            } <
                            /select> {
                                loading && ( <
                                    >
                                    <
                                    div class = "spinner-border spinner-border-sm me-2 mt-2"
                                    role = "status" >
                                    <
                                    span class = "visually-hidden" > < /span> <
                                    /div>
                                    Checking Username <
                                    />
                                )
                            } <
                            div >
                            <
                            span className = "text-success" > {
                                playerCheck && "Username: " + playerCheck
                            } <
                            /span> <
                            /div> <
                            />
                        )
                    )
                } {
                    product ? .playerCheckBtn === "yes" && ( <
                        button className = "buy-now"
                        onClick = {
                            handleCheckPlayer
                        } >
                        Check Username <
                        /button>
                    )
                } <
                /div>

                { /* ====================== PACKAGE ===============  */ } { /* ====================== PACKAGE ===============  */ } <
                div className = "bg-fields" >
                <
                h5 > Select Package < /h5> <
                div className = "p-amount" > {
                    product ? .cost ? .map((item, index) => {
                        return ( <
                            div onClick = {
                                () => {
                                    setAmount(item.amount);
                                    setPriceAndId(item.amount);
                                }
                            }
                            key = {
                                index
                            }
                            className = {
                                `amount ${
                        amount === item?.amount && "active"
                      }`
                            } >
                            <
                            span >
                            <
                            div className = {
                                `amt-img ${
                            amount === item?.amount && "active"
                          }`
                            } >
                            <
                            div > {
                                item.amount
                            } < /div> <
                            img src = {
                                item ? .pimg
                            }
                            alt = "" / >
                            <
                            /div> <
                            div className = "price" > ₹{
                                user ? .reseller === "yes" ?
                                item ? .resPrice :
                                item ? .price
                            } <
                            /div> <
                            /span> <
                            /div>
                        );
                    })
                } <
                /div> <
                /div>

                { /* ====================== PAYMENT METHOD ===============  */ } { /* ====================== PAYMENT METHOD ===============  */ } <
                div className = "bg-fields" >
                <
                h5 > Select Payment < /h5> <
                div className = "payment-container" >
                <
                div onClick = {
                    () => {
                        setMode("WALLET");
                        setPaymentOptions("");
                    }
                }
                className = {
                    `payment wallet ${mode === "WALLET" && "active"}`
                } >
                <
                WalletIcon className = "icon" / >
                wallet <
                /div> <
                div onClick = {
                    () => {
                        setMode("UPI");
                    }
                }
                className = {
                    `payment upi ${mode === "UPI" && "active"}`
                } >
                <
                img src = {
                    IMAGES.upi
                }
                alt = "" / >
                UPI <
                /div> <
                /div> <
                /div>

                { /* COUPON  */ } {
                    /* <div className="bg-fields">
                                  {couponApplied ? (
                                    <>
                                      <h5>Discount Applied</h5>
                                      <div className="coupon-tag">
                                        <p className="m-0">
                                          {couponName} <CheckCircleOutlineIcon className="icon" />
                                        </p>
                                        <button className="remove-coupon" onClick={removeDiscount}>
                                          Remove
                                        </button>
                                      </div>
                                    </>
                                  ) : (
                                    <>
                                      <h5>Apply Coupon</h5>
                                      <div className="coupon-box">
                                        <input
                                          className="player-tag m-0"
                                          type="text"
                                          name="coupon"
                                          placeholder="Enter Coupon"
                                          onChange={(e) => setCoupon(e.target.value)}
                                          value={coupon}
                                        />
                                        <button onClick={applyCoupon}>Apply</button>
                                      </div>
                                    </>
                                  )}
                                  {error && coupon === "" && (
                                    <span className="text-danger">Enter valid coupon</span>
                                  )}
                                </div> */
                }

                { /* ========================================= */ } <
                div className = "bg-fields" >
                <
                div className = "total-value" >
                <
                h5 > Buy Now < /h5> <
                div className = "text-end" >
                <
                p className = "m-0" >
                <
                b > Rs. {
                    finalAmount
                } < /b> <
                /p> <
                span >
                <
                small >
                Amount {
                    amount
                } | {
                    " "
                } <
                span >
                Using - {
                    paymentOptions !== "" ? paymentOptions : mode
                } <
                /span> <
                /small> <
                /span> <
                /div> <
                /div> <
                div className = "buy-btn-container" > {
                    user ? .block === "yes" || product ? .stock === "no" ? ( <
                        button className = "buy-now"
                        style = {
                            {
                                opacity: "0.7"
                            }
                        } >
                        Out of Stock <
                        /button>
                    ) : !user ? ( <
                        button onClick = {
                            () => navigate("/login")
                        }
                        className = "buy-now" >
                        Please Login First <
                        /button>
                    ) : ( <
                        button onClick = {
                            checkPlaceOrder
                        }
                        className = "buy-now" >
                        BUY NOW <
                        /button>
                    )
                } <
                /div> <
                /div> <
                /div> <
                /div>
            )
        } <
        /Layout>
    );
};

export default ProductInfo;